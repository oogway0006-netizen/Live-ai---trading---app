import "dotenv/config";
import express from "express";
import cors from "cors";
import { WebSocketServer, WebSocket } from "ws";
import http from "http";
import path from "path";
import { fileURLToPath } from "url";

const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.TWELVE_DATA_API_KEY;

if (!API_KEY) {
  console.warn("TWELVE_DATA_API_KEY is missing. Copy .env.example to .env and add your key.");
}

const app = express();
const server = http.createServer(app);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const TD_BASE = "https://api.twelvedata.com";

function cleanSymbol(symbol) {
  return String(symbol || "EUR/USD").trim().toUpperCase();
}

function allowedInterval(interval) {
  const allowed = new Set(["1min","5min","15min","30min","45min","1h","2h","4h","8h","1day","1week","1month"]);
  return allowed.has(interval) ? interval : "15min";
}

async function tdFetch(endpoint, params = {}) {
  if (!API_KEY) throw new Error("Missing TWELVE_DATA_API_KEY on the server.");
  const url = new URL(`${TD_BASE}${endpoint}`);
  for (const [k, v] of Object.entries({ ...params, apikey: API_KEY })) {
    url.searchParams.set(k, v);
  }
  const res = await fetch(url);
  const data = await res.json();
  if (!res.ok || data.status === "error" || data.code) {
    throw new Error(data.message || `Twelve Data HTTP ${res.status}`);
  }
  return data;
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function normalizeValues(data) {
  if (!data?.values) return [];
  return [...data.values].reverse().map(x => ({
    datetime: x.datetime,
    open: toNumber(x.open),
    high: toNumber(x.high),
    low: toNumber(x.low),
    close: toNumber(x.close),
    volume: toNumber(x.volume)
  })).filter(x => [x.open,x.high,x.low,x.close].every(Number.isFinite));
}

function ema(values, period) {
  if (values.length < period) return null;
  const k = 2 / (period + 1);
  let e = values.slice(0, period).reduce((a,b)=>a+b,0) / period;
  for (let i = period; i < values.length; i++) e = values[i] * k + e * (1-k);
  return e;
}

function rsi(values, period = 14) {
  if (values.length <= period) return null;
  let gains = 0, losses = 0;
  for (let i=1;i<=period;i++) {
    const d = values[i]-values[i-1];
    if (d >= 0) gains += d; else losses -= d;
  }
  let avgGain = gains / period, avgLoss = losses / period;
  for (let i=period+1;i<values.length;i++) {
    const d = values[i]-values[i-1];
    const gain = Math.max(d,0), loss = Math.max(-d,0);
    avgGain = (avgGain*(period-1)+gain)/period;
    avgLoss = (avgLoss*(period-1)+loss)/period;
  }
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100/(1+rs));
}

function atr(candles, period=14) {
  if (candles.length <= period) return null;
  const tr = [];
  for (let i=1;i<candles.length;i++) {
    const c = candles[i], p = candles[i-1];
    tr.push(Math.max(c.high-c.low, Math.abs(c.high-p.close), Math.abs(c.low-p.close)));
  }
  let a = tr.slice(0,period).reduce((x,y)=>x+y,0)/period;
  for (let i=period;i<tr.length;i++) a = (a*(period-1)+tr[i])/period;
  return a;
}

function analyzeCandles(candles) {
  if (candles.length < 60) return { signal:"WAIT", confidence:0, reason:"Not enough candles for analysis." };
  const closes = candles.map(c=>c.close);
  const price = closes.at(-1);
  const e20 = ema(closes,20);
  const e50 = ema(closes,50);
  const r = rsi(closes,14);
  const a = atr(candles,14);

  let score = 0;
  const reasons = [];
  if (e20 > e50) { score += 2; reasons.push("EMA20 is above EMA50"); }
  else { score -= 2; reasons.push("EMA20 is below EMA50"); }

  if (price > e20) { score += 1; reasons.push("Price is above EMA20"); }
  else { score -= 1; reasons.push("Price is below EMA20"); }

  if (r >= 52 && r <= 70) { score += 1; reasons.push("RSI supports bullish momentum"); }
  else if (r <= 48 && r >= 30) { score -= 1; reasons.push("RSI supports bearish momentum"); }
  else if (r > 70) reasons.push("RSI is overbought");
  else if (r < 30) reasons.push("RSI is oversold");

  const signal = score >= 3 ? "BUY" : score <= -3 ? "SELL" : "WAIT";
  const confidence = Math.min(95, 50 + Math.abs(score)*10);
  return {
    signal, confidence, price,
    ema20:e20, ema50:e50, rsi:r, atr:a,
    reasons
  };
}

function multiTimeframeResult(results) {
  const scores = results.map(x => x.analysis.signal === "BUY" ? 1 : x.analysis.signal === "SELL" ? -1 : 0);
  const total = scores.reduce((a,b)=>a+b,0);
  const signal = total >= 2 ? "BUY" : total <= -2 ? "SELL" : "WAIT";
  const confidence = Math.min(95, 50 + Math.abs(total)*12);
  const base = results.find(x => x.interval === "15min")?.analysis || results[0].analysis;
  const price = base.price;
  const a = base.atr || Math.max(price*0.001, 0.0001);

  let entry = price;
  let sl, tp1, tp2, tp3;
  if (signal === "BUY") {
    sl = price - 1.5*a; tp1 = price + 1.5*a; tp2 = price + 3*a; tp3 = price + 4.5*a;
  } else if (signal === "SELL") {
    sl = price + 1.5*a; tp1 = price - 1.5*a; tp2 = price - 3*a; tp3 = price - 4.5*a;
  } else {
    sl = price - 1.5*a; tp1 = price + 1.5*a; tp2 = price + 3*a; tp3 = price + 4.5*a;
  }

  return {
    signal, confidence, price, entry, sl, tp1, tp2, tp3,
    timeframes: results.map(x => ({
      interval:x.interval, signal:x.analysis.signal, confidence:x.analysis.confidence,
      rsi:x.analysis.rsi, ema20:x.analysis.ema20, ema50:x.analysis.ema50
    }))
  };
}

app.get("/api/health", (_req,res) => {
  res.json({ ok:true, provider:"Twelve Data", keyConfigured:Boolean(API_KEY), time:new Date().toISOString() });
});

app.get("/api/candles", async (req,res) => {
  try {
    const symbol = cleanSymbol(req.query.symbol);
    const interval = allowedInterval(req.query.interval);
    const outputsize = Math.min(Math.max(Number(req.query.outputsize || 200), 20), 5000);
    const data = await tdFetch("/time_series", { symbol, interval, outputsize, order:"asc" });
    res.json({ symbol, interval, candles:normalizeValues(data) });
  } catch (e) {
    res.status(502).json({ error:e.message });
  }
});

app.get("/api/quote", async (req,res) => {
  try {
    const symbol = cleanSymbol(req.query.symbol);
    const data = await tdFetch("/quote", { symbol });
    res.json(data);
  } catch (e) {
    res.status(502).json({ error:e.message });
  }
});

app.get("/api/analyze", async (req,res) => {
  try {
    const symbol = cleanSymbol(req.query.symbol);
    const intervals = ["15min","1h","4h"];
    const results = [];
    for (const interval of intervals) {
      const data = await tdFetch("/time_series", { symbol, interval, outputsize:200, order:"asc" });
      const candles = normalizeValues(data);
      results.push({ interval, candles, analysis:analyzeCandles(candles) });
    }
    const result = multiTimeframeResult(results);
    res.json({ symbol, generatedAt:new Date().toISOString(), ...result });
  } catch (e) {
    res.status(502).json({ error:e.message });
  }
});

// Backend WebSocket proxy. The browser never receives the Twelve Data API key.
const wss = new WebSocketServer({ server, path:"/ws" });

wss.on("connection", client => {
  let upstream = null;
  let subscribed = false;

  const closeUpstream = () => {
    if (upstream) {
      try { upstream.close(); } catch {}
      upstream = null;
    }
  };

  client.on("message", raw => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.action !== "subscribe") return;
      const symbols = String(msg.symbols || "EUR/USD").trim();
      closeUpstream();

      if (!API_KEY) {
        client.send(JSON.stringify({ type:"error", message:"Server API key is not configured." }));
        return;
      }

      upstream = new WebSocket(`wss://ws.twelvedata.com/v1/quotes/price?apikey=${encodeURIComponent(API_KEY)}`);

      upstream.on("open", () => {
        upstream.send(JSON.stringify({ action:"subscribe", params:{ symbols } }));
        subscribed = true;
        client.send(JSON.stringify({ type:"status", status:"connected", symbols }));
      });

      upstream.on("message", data => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(data.toString());
        }
      });

      upstream.on("error", err => {
        if (client.readyState === WebSocket.OPEN)
          client.send(JSON.stringify({ type:"error", message:err.message }));
      });

      upstream.on("close", () => {
        if (client.readyState === WebSocket.OPEN)
          client.send(JSON.stringify({ type:"status", status:"disconnected" }));
      });
    } catch {
      if (client.readyState === WebSocket.OPEN)
        client.send(JSON.stringify({ type:"error", message:"Invalid WebSocket message." }));
    }
  });

  client.on("close", closeUpstream);
});

app.get("*", (_req,res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

server.listen(PORT, () => {
  console.log(`LiveAI Trading App running on http://localhost:${PORT}`);
});
