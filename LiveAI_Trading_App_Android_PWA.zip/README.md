# LiveAI Trading App — Backend + API

This version changes the app from a browser-only prototype into:

Browser app → Node/Express backend → Twelve Data API/WebSocket

## 1. Get a Twelve Data API key

Create a Twelve Data account and copy your API key from the dashboard.

## 2. Configure the key

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Then put your key in:

```text
TWELVE_DATA_API_KEY=YOUR_REAL_KEY
```

Never put the permanent key inside `public/index.html` and never commit `.env`.

## 3. Install

```bash
npm install
```

## 4. Run

```bash
npm start
```

Open:

```text
http://localhost:3000
```

## What is now real

- Historical OHLC candles from the backend
- Real-time quote stream through the backend WebSocket proxy
- Symbol switching
- M1/M5/M15/M30/H1/H4 chart intervals
- Multi-timeframe analysis using M15, H1 and H4
- EMA20/EMA50
- RSI(14)
- ATR(14)
- BUY / SELL / WAIT engine
- Entry, SL, TP1 and TP2 calculations

## Important

The current analysis engine is a technical-analysis prototype, not a guaranteed-profit AI. Before real-money use, add backtesting, spread/slippage handling, broker-specific pricing, signal logging, position/risk controls, and forward testing.

Twelve Data's WebSocket service uses an API key and subscription messages for real-time quotes. Historical OHLC is available through the time-series endpoint.


## Install on Android like an app (PWA)

1. Run/deploy the backend over HTTPS.
2. Open the web address in Chrome on your Android phone.
3. Tap the Chrome menu (⋮).
4. Choose **Add to Home screen** or **Install app**.
5. LiveAI will appear as an app icon and open in standalone mode.

The app still needs the Node backend and Twelve Data API key configured on the server for live market data.
